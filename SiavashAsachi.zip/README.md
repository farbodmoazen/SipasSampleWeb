# SipasSampleWeb
It's a shopping store based on Html,Css,Bootstrap and JavaScript.
colors and variables are in css
each section of html page has a css file
